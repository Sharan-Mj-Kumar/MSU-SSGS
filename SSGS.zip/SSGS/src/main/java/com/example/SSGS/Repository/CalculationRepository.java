package com.example.SSGS.Repository;

import com.example.SSGS.Tables.Calculation;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CalculationRepository extends JpaRepository<Calculation, Integer> {
}
